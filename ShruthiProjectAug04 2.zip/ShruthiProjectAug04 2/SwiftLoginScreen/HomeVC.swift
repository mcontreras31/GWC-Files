//
//  HomeVC.swift
//  SwiftLoginScreen
//
//  Created by Meghana Chigurupati on 31/07/14.
//  Copyright (c) 2014 Dipin Krishna. All rights reserved.

import UIKit

class HomeVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet var usernameLabel : UILabel!
    
    
    @IBOutlet weak var imagePicked: UIImageView!
    @IBAction func openCameraButton(sender: AnyObject) {
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            imagePicker.allowsEditing = false
            self.presentViewController(imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func openPhotoLibrary(sender: AnyObject) {
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary;
            imagePicker.allowsEditing = true
            self.presentViewController(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!){
        imagePicked.image = image
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    
    @IBAction func saveButt(sender: UIButton) {
        
        //  let imageData = UIImageJPEGRepresentation(imagePicked.image!, 0.6)
        //  let compressedJPGImage = UIImage(data: imageData!)
        //  UIImageWriteToSavedPhotosAlbum(compressedJPGImage!, nil, nil, nil)
        
        
        //Save image
        let img = UIImage() //Change to be from UIPicker
        let data = UIImagePNGRepresentation(img)
        NSUserDefaults.standardUserDefaults().setObject(data, forKey: "myImageKey")
        NSUserDefaults.standardUserDefaults().synchronize()
        
        //Get image
        if let imgData = NSUserDefaults.standardUserDefaults().objectForKey("myImageKey") as? NSData {
            let retrievedImg = UIImage(data: imgData)
        
        
        }
    }
    
    
    //oveeride
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imagePicked.layer.cornerRadius = 10;
        self.imagePicked.clipsToBounds = true;

        

        // Do any additional setup after loading the view.
    }
    
    
    //override
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(true)
        
        let prefs:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        let isLoggedIn:Int = prefs.integerForKey("ISLOGGEDIN") as Int
        if (isLoggedIn != 1) {
            self.performSegueWithIdentifier("goto_login", sender: self)
        } else {
            self.usernameLabel.text = prefs.valueForKey("USERNAME") as? String
        }
        
    }

   
    

    /*
    // #pragma mark - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue?, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func logoutTapped(sender : UIButton) {
        
        let appDomain = NSBundle.mainBundle().bundleIdentifier
        NSUserDefaults.standardUserDefaults().removePersistentDomainForName(appDomain!)
        
        self.performSegueWithIdentifier("goto_login", sender: self)
    }
}


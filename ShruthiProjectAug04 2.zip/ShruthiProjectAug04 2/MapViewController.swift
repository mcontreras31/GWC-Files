//
//  MapViewController.swift
//  SwiftLoginScreen
//
//  Created by SIS on 8/3/16.
//  Copyright © 2016 Dipin Krishna. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate,CLLocationManagerDelegate {



    @IBOutlet var coorLabel3: UILabel!
    @IBOutlet var coorLabel2: UILabel!
    @IBOutlet var coorLabel: UILabel!
    @IBOutlet weak var loc: MKMapView!
    var latitudeDegrees = []
    
    
    
    let locationManger = CLLocationManager()
    var myLocations = [CLLocation]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

        self.locationManger.delegate = self
        self.locationManger.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManger.requestWhenInUseAuthorization()
        self.locationManger.startUpdatingLocation()
        self.loc.showsUserLocation = true
        coorLabel.font = UIFont (name: "Cochin", size: 14)
        coorLabel2.font = UIFont(name: "Cochin", size: 14)
        coorLabel3.font = UIFont(name: "Cochin", size: 14)
        coorLabel3.lineBreakMode = NSLineBreakMode.ByWordWrapping
        coorLabel3.numberOfLines = 3


        
        
    }
    
    func locationManager(manager:CLLocationManager,didUpdateLocations locations: [CLLocation]){
        
        let location = locations.last
        
        let center = CLLocationCoordinate2D(latitude:location!.coordinate.latitude, longitude: location!.coordinate.longitude)
        
        
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 4, longitudeDelta: 4))
        
        self.loc.setRegion(region, animated:true)
        
        self.locationManger.stopUpdatingLocation()
        
        myLocations.append(locations.last!)
        
        print(myLocations)
        print("hello, from the other side")
        
        print("this is me printing random things to see if my code works")
        print("if my code does work, these lines should print.")
        print("Lets Check it Out!")
        let latitude = locationManger.location?.coordinate.latitude
        let longitude = locationManger.location?.coordinate.longitude
        
        //coorLabel.text = ("Hi My location is \(String(myLocations[0]))")
        
        if ((latitude >= 35 && latitude <= 50)&&(longitude <= -80 && longitude >= -105)){
            coorLabel.text =  ("Autism Speaks Midwest Employment Symposium 3/13/16 1999 Campus Drive, Evanston, IL 60208")
            coorLabel2.text = ("Seizure Training by Epilepsy Foundation Minnesota: 6/21/16 The Inn on Lake Superior")
            coorLabel3.text = ("Date : 9/24/16 Hosted By: PEARS Event Name: Croquet for a Cure")
            
            
            //coorLabel3.text = ("Croquet for a CURE hosted by PEARS 9/24/16")
            

        }
        else if ((latitude >= 35 && latitude <= 50) && (longitude <= -60 && longitude >= -81)){
            coorLabel.text = ("Thompson Island 4K 9/22/16 Boston Harbor Boston, MA 02210")
            coorLabel2.text = ("Autism Speaks New York City Walk 9/10/16")
            coorLabel3.text = ("CHOP Buddy Walk and Family Fun Day 10/2/16 Children's Hospital of Philedelphia 185 Ithan Ave., Villanova, PA 19010")
        }
        else if ((latitude >= 25 && latitude <= 35) && (longitude <= -70 && longitude >= -106)){
            coorLabel.text = ("Autism Speaks Walk 10/1/16 Austin TX")
            coorLabel2.text = ("Purple Hat Fashion Sunday Brunch 11/6/16 Greater Fort Lauderdale Chamber of Commerce in Fort Lauderdale")
            coorLabel3.text = ("19th Annual Buddy Walk in Atlanta, GA 10/16/16 Centennial Olympic Park")
        }
        else if ((latitude >= 25 && latitude <= 50) && (longitude <= -100 && longitude >= -110)){
            coorLabel.text = ("Hope Gala Moonlight Masquerade 11/5/16 Ritz Carlton Denver")
            coorLabel2.text = ("Colorado Springs Strides for Epilepsy 5K 9/11/16 Memorial Park Colorado Springs")
            coorLabel3.text = ("9/24/16 Rio Grande Down Syndrome Buddy Walk")
        }
        else if ((latitude >= 30 && latitude <= 50) && (longitude <= -111 && longitude >= -130)){
            coorLabel.text = ("Special Needs Jump Sessions Tuesdays starting 8/2/16 3-6 PM Santa Clara Sky High Sports, 2880 Mead Ave, Santa Claara, CA 95051")
            coorLabel2.text = ("Epilepsy Walk & Family Carnival of Orange County 4/23/16")
            coorLabel3.text = ("Aging Matters: Growing Older with Down Syndrome- Free conference 11/19/16 Arizona")
        }
        
        

        
        
        
//        if (myLocations[0] == 45){
//            
//        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
